package edu.ccrm.exception;

public class DuplicateEnrollmentException extends Exception {
    public DuplicateEnrollmentException(String msg){
        super(msg);
    }
}
