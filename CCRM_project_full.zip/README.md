# Campus Course & Records Manager (CCRM)

Programming in Java Project

## Evolution of Java (short notes)
- 1995: Java 1.0 by Sun Microsystems
- 2004: Java 5 (Generics, annotations)
- 2014: Java 8 (Lambdas, Stream API)
- 2017+: Java 9+ modular system, records, sealed classes, pattern matching

## Java Editions (ME / SE / EE)
| Edition | Use |
|---------|-----|
| Java ME | Mobile / embedded devices |
| Java SE | Standard desktop/server development |
| Java EE | Enterprise apps (servlets, EJB, JPA) |

## JVM / JRE / JDK
- **JVM**: runs bytecode
- **JRE**: JVM + libraries
- **JDK**: JRE + compiler/tools

## Installation Steps (Windows)
1. Download JDK from Oracle/OpenJDK site
2. Install and set JAVA_HOME, PATH
3. Verify with `java -version` (screenshot in docs/screenshots/)

## Eclipse Setup
1. Download Eclipse IDE
2. Import project as Java project
3. Configure JDK
4. Run `Main`

## Mapping: Syllabus topic → Files
| Topic | Example file/method |
|-------|---------------------|
| Encapsulation | `Student` private fields + getters |
| Inheritance | `Person` → `Student` |
| Polymorphism | `Student.profile()` override |
| Builder | `Course.Builder`, `Student.Builder` |
| Singleton | `AppConfig` |
| Enums | `Semester`, `Grade` |
| Date/Time API | `Student.createdAt`, backups timestamp |
| Streams | `ReportsCLI` GPA distribution |
| Collections | `StudentService` uses List |
| NIO.2 | `ImportExportService.createBackup`, `FileUtil.folderSize` |
| Custom Exceptions | `DuplicateEnrollmentException`, `MaxCreditLimitExceededException` |
| Arrays & Sorting | `ExtraExamples.demonstrate()` |
| Recursion | `ExtraExamples.factorial()` |
| Control flow | `Main`, `ExtraExamples` loops |

## How to run
See `USAGE.md`

## Screenshots
Put screenshots in `docs/screenshots/` before submission.
