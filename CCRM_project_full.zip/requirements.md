# Special requirements

- JDK 17 or later recommended.
- No external libraries needed.
- Program reads/writes CSVs from `data/test-data/` and creates backups in `data/backups/`.
- To enable Java assertions, run with `-ea`.
